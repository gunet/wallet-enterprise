const { parsePda1Data, parseEhicData, parsePidData } = require('.')


const res = parsePidData('./dataset-new-mapping.xlsx')

console.log("Res = ", res[0])
